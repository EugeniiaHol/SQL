1\ В схеме employees, в таблице employees добавить новый столбец - lang_no (int);

SELECT * FROM employees;

ALTER TABLE employees.employees 
ADD lang_no int;

2\ Обновить столбец lang_no значением "1" для всех у кого год прихода на работу 1985 и
1988. Остальным значение сотрудникам обновить значение "2";

DROP VIEW due;

CREATE VIEW due AS
SELECT emp_no, 
CASE
        WHEN YEAR(hire_date) IN (1985,1988) THEN 1 
        ELSE 2
    END AS due
FROM employees;
SELECT * FROM due;

UPDATE employees e
INNER JOIN due d USING(emp_no)
SET e.lang_no = d.due;
SELECT * FROM employees;

3\ В схеме tempdb, создать новую таблицу language с двумя полями lang_no (int) и
lang_name (varchar(3));

USE tempdb;
CREATE TABLE `language` (lang_no INT, lang_name VARCHAR(3));

4\ Добавить в таблицу tempdb.language две строки: 1 - ukr, 2 - rus;

INSERT INTO `language`(lang_no,lang_name)
VALUES(1,'ukr'),
      (2,'rus');
      
SELECT * FROM `language`;

5\ Связать таблицы из схемы employees и tempdb чтобы показать всю информацию из
таблицы employees и один столбец lang_name из таблицы language (столбцы lang_no не отображать);

SELECT e.emp_no, e.birth_date, e.first_name, e.last_name, e.gender, e.hire_date, l.lang_name
FROM employees.employees e
INNER JOIN 
tempdb.language l ON e.lang_no = l.lang_no;

6\ На основе запроса из 5-го задания, создать вью employees_lang;
USE employees;

DROP VIEW employees_lang;

CREATE VIEW employees_lang AS
SELECT e.emp_no, e.birth_date, e.first_name, e.last_name, e.gender, e.hire_date, l.lang_name
FROM employees.employees e
INNER JOIN 
tempdb.language l ON e.lang_no = l.lang_no;

SELECT * FROM employees_lang;

7\ Через вью employees_lang вывести количество сотрудников в разрезе языка;

SELECT lang_name, COUNT(lang_name) total_count
FROM employees_lang
GROUP BY lang_name;