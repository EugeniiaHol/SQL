1.\Отобразить сотрудников и напротив каждого, показать информацию о разнице текущей и первой зарплаты;
/* 1.Можна було б ще викинути тих, у кого одна позиція*/

SELECT subq.emp_no, subq.salary-subq.b AS value_diff FROM (
SELECT 
emp_no, 
salary, 
from_date, 
to_date, 
FIRST_VALUE(salary) OVER(PARTITION BY emp_no ORDER BY from_date) AS b FROM salaries) AS subq 
WHERE curdate() < subq.to_date and subq.salary<>subq.b
ORDER BY 1;

2.\Отобразить департаменты и сотрудников, которые получают наивысшую зарплату в своем департаменте;
/* 2. Ви показали всіх людей. Потрібно було ще у наступному запиті пофільтрвати результат після віконки*/

SELECT msd.dd as dept_nom, msd.de as emp_nom FROM (SELECT d.dept_no dd, d.emp_no de, s.salary s, MAX(s.salary) OVER(PARTITION BY d.dept_no) ms
FROM dept_emp d 
JOIN salaries s on d.emp_no = s.emp_no
WHERE CURRENT_DATE() BETWEEN s.from_date AND s.to_date) AS msd
WHERE msd.s = msd.ms
ORDER BY 1
;

3.\Из таблицы должностей, отобразить сотрудника с его текущей должностью и предыдущей.
HINT OVER(PARTITION BY ... ORDER BY ... ROWS 1 preceding);
/* 3. Ви пройшлись по всіх рядках в базі. А потрібно отримати в результаті один раз прцівника, його теперішню посаду і попередню. 
Якщо була одна посада - викинути такого, або позначити окремо */

SELECT tit.en as emp_nom, tit.pt as prev_title, tit.ct as novaday_title FROM (SELECT emp_no en, from_date fd, to_date td, 
LAST_VALUE(title) OVER(PARTITION BY emp_no ORDER BY from_date ROWS 1 PRECEDING) pt,     
LAST_VALUE(title) OVER(PARTITION BY emp_no ORDER BY from_date RANGE BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) ct     
FROM titles) AS tit
WHERE tit.pt <> tit.ct;

4.\Из таблицы должностей, посчитать интервал в днях - сколько прошло времени от первой должности до текущей;

1-й спосіб (довгий);
DROP VIEW IF EXISTS d1;
DROP VIEW IF EXISTS d2;

CREATE OR REPLACE VIEW d1 AS
SELECT emp_no, f_date FROM (
SELECT *, FIRST_VALUE(from_date) OVER (PARTITION BY emp_no ORDER BY from_date) f_date FROM employees.titles
) As first_date
WHERE curdate() BETWEEN from_date AND to_date;

CREATE OR REPLACE  VIEW d2 AS
SELECT emp_no, last_f_date FROM (
SELECT *, LAST_VALUE(from_date) OVER (PARTITION BY emp_no ORDER BY from_date RANGE BETWEEN CURRENT ROW AND UNBOUNDED FOLLOWING) last_f_date FROM employees.titles
) AS last_date
WHERE curdate() BETWEEN from_date AND to_date;

SELECT d1.emp_no, timestampdiff(Day, d1.f_date, d2.last_f_date) difday FROM d1
INNER JOIN d2 ON d1.emp_no = d2.emp_no ;

2-й спосіб (за прикладом);
SELECT subq.*, timestampdiff(Day, subq.d, subq.from_date) AS date_diff FROM (SELECT emp_no, title, from_date, to_date, FIRST_VALUE(from_date) OVER(PARTITION BY emp_no ORDER BY from_date) AS d FROM titles ) 
AS subq WHERE subq.to_date > now();

5.\Выбрать сотрудников и отобразить их рейтинг по году принятия на работу. Попробуйте разные типы рейтингов;
/* 5. пропустили partition by. */

SELECT emp_no, hire_date, RANK() OVER(ORDER BY year(hire_date)) ran_year FROM employees;
SELECT emp_no, hire_date, DENSE_RANK() OVER(ORDER BY year(hire_date)) ran_year FROM employees;