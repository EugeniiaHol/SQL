SQL степ-проект
--------------------------------------------------------------------------------------------------------------------------------------------------
І Розділ
Запросы
1.\ Покажите среднюю зарплату сотрудников за каждый год (средняя заработная плата среди тех, 
кто работал в отчетный период - статистика с начала до 2005 года);
USE `employees`; 

SELECT 
    YEAR(from_date) ye_r, 
    round(AVG(salary),2) avg_sal
FROM
    salaries
   WHERE to_date < '2005-01-01'
   GROUP BY 1
   ORDER BY 1;

2.\Покажите среднюю зарплату сотрудников по каждому отделу. Примечание: принять в расчет только текущие отделы и текущую заработную плату;

SELECT 
    d.dept_no, ROUND(AVG(s.salary), 2) avg_s
FROM
    dept_emp d
        INNER JOIN
    salaries s ON d.emp_no = s.emp_no
WHERE
    CURDATE() BETWEEN s.from_date AND s.to_date
        AND CURDATE() BETWEEN d.from_date AND d.to_date
GROUP BY 1
ORDER BY 1;

3.\Покажите среднюю зарплату сотрудников по каждому отделу за каждый год. 
Примечание: 
для средней зарплаты отдела X в году Y нам нужно взять среднее значение всех зарплат в году Y сотрудников, которые были в отделе X в году Y;

CREATE OR REPLACE VIEW avg_sal AS
SELECT 
    d.dept_no, year(d.from_date) year_d, ROUND(AVG(s.salary), 2) avg_s
FROM
    dept_emp d
        INNER JOIN
    salaries s ON d.emp_no = s.emp_no
GROUP BY 1, 2
ORDER BY 1, 2;

SELECT * FROM avg_sal;

4.\Покажите для каждого года самый крупный отдел (по количеству сотрудников) в этом году и его среднюю зарплату;
		
     1-й спосіб через вью;
DROP VIEW IF EXISTS count_demp;
CREATE OR REPLACE VIEW count_demp AS
SELECT a.dept_no AS adn, a.year_d AS ayd,  a.avg_s AS avs, COUNT(d.emp_no) c_emp
    FROM
    dept_emp d
    INNER JOIN avg_sal AS a ON year(d.from_date) = a.year_d AND d.dept_no = a.dept_no
GROUP BY 2, 1
ORDER BY 2, 4 DESC;

SELECT ayd, FIRST_VALUE(adn) OVER(PARTITION BY(ayd)) AS department, FIRST_VALUE(avs) OVER(PARTITION BY(ayd)) AS avg_sal_dep FROM count_demp
GROUP BY 1;
 
 2-й спосіб через підзапит;
SELECT cd.ayd AS years, FIRST_VALUE(cd.adn) OVER(PARTITION BY(cd.ayd)) department, FIRST_VALUE(cd.avs) OVER(PARTITION BY(cd.ayd)) avg_sal_dep FROM 
(SELECT a.dept_no AS adn, a.year_d AS ayd,  a.avg_s AS avs, COUNT(d.emp_no) AS c_emp
    FROM
    dept_emp d
    INNER JOIN avg_sal AS a ON year(d.from_date) = a.year_d AND d.dept_no = a.dept_no
GROUP BY 2, 1
ORDER BY 2, 4 DESC) AS cd
GROUP BY 1;

5.\Покажите подробную информацию о менеджере, который дольше всех исполняет свои обязанности на данный момент;

SELECT 
subq1.se AS emp_nom, 
subq1.sd AS dept_nom, 
e.first_name,
e.last_name,
e.birth_date,
e.gender,
e.hire_date,
MAX(subq1.date_diff) OVER(ORDER BY subq1.date_diff) AS max_date_diff
FROM (SELECT 
		subq.emp_no AS se, 
		subq.dept_no AS sd, 
        subq.from_date AS sf, 
        timestampdiff(Day, subq.d, now()) AS date_diff 
        FROM (SELECT 
			emp_no, 
            dept_no, 
            from_date, 
            to_date, 
            FIRST_VALUE(from_date) OVER(PARTITION BY emp_no ORDER BY from_date) AS d 
            FROM dept_manager) 
		AS subq WHERE subq.to_date > now()
			) AS subq1
            LEFT JOIN employees e ON subq1.se = e.emp_no
            ORDER BY 8 DESC 
            LIMIT 1;

6.\Покажите топ-10 нынешних сотрудников компании с наибольшей разницей между их зарплатой и текущей средней зарплатой в их отделе;

SELECT 
dsal.dd AS dept_nom, 
dsal.de AS emp_nom, 
round(dsal.ss - AVG(dsal.ss) OVER(PARTITION BY dsal.dd),2) AS diff  
FROM (SELECT 
			d.dept_no dd,
			d.emp_no de, 
			s.salary ss
			FROM salaries s 
			INNER JOIN dept_emp d ON s.emp_no = d.emp_no
			WHERE curdate() BETWEEN d.from_date AND d.to_date AND
			curdate() BETWEEN s.from_date AND s.to_date
			ORDER BY 1) AS dsal
	ORDER BY 3 DESC
    LIMIT 10
    ;

7.\Из-за кризиса на одно подразделение на своевременную выплату зарплаты выделяется всего 500 тысяч долларов. 
Правление решило, что низкооплачиваемые сотрудники будут первыми получать зарплату. 
Показать список всех сотрудников, которые будут вовремя получать зарплату 
(обратите внимание, что мы должны платить зарплату за один месяц, но в базе данных мы храним годовые суммы);
	
 SELECT 
 rez.mdd AS dept_nom,
 rez.mde AS emp_nom,
 rez.mss AS momth_sal,
 -- rez.t AS total,
 COUNT(rez.mde) OVER(PARTITION BY rez.mdd) AS count_dept_emp
 FROM (SELECT 
   mes.dd AS mdd,
   mes.de AS mde,
   mes.ss AS mss,
   coalesce(SUM(mes.ss) OVER(PARTITION BY mes.dd ORDER BY mes.ss ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW),0) AS t 
   /* Приклад використання віконної функції coalesce знайшла за адресою https://habr.com/ru/post/474458/ */
   FROM (SELECT  
			d.dept_no AS dd,
			d.emp_no AS de, 
			round(s.salary/12,2) AS ss
			FROM salaries s 
			INNER JOIN dept_emp d ON s.emp_no = d.emp_no
			WHERE curdate() BETWEEN d.from_date AND d.to_date AND
			curdate() BETWEEN s.from_date AND s.to_date
			ORDER BY 1, 3) AS mes) AS rez
		WHERE rez.t <= 500000
     ;

___________________________________________________________________________________________________________________________________________________
II Розділ.
Дизайн базы данных:
1.Разработайте базу данных для управления курсами. 
База данных содержит следующие сущности:
students: student_no, teacher_no, course_no, student_name, email, birth_date;
teachers: teacher_no, teacher_name, phone_no;
courses: course_no, course_name, start_date, end_date;
Секционировать по годам, таблицу students по полю birth_date с помощью механизма range●
В таблице students сделать первичный ключ в сочетании двух полей student_noи birth_date● 
Создать индекс по полю students.email●
Создать уникальный индекс по полю teachers.phone_no;

DROP DATABASE IF EXISTS courses;

CREATE DATABASE IF NOT EXISTS courses;

SHOW DATABASES;

USE courses;

DROP TABLE IF EXISTS students;
CREATE TABLE IF NOT EXISTS students ( 
student_no INT(7) AUTO_INCREMENT NOT NULL, 
teacher_no INT(5) NOT NULL, 
course_no INT(3) NOT NULL, 
student_name VARCHAR(50) NOT NULL, 
email VARCHAR(50) NOT NULL, 
birth_date DATE,
PRIMARY KEY (student_no, birth_date),
INDEX students (email)
  ) ENGINE=INNODB
PARTITION BY RANGE COLUMNS(birth_date) (
PARTITION p0 VALUES LESS THAN('2005-01-01'),
PARTITION p1 VALUES LESS THAN('2006-01-01'),
PARTITION p2 VALUES LESS THAN('2007-01-01'),
PARTITION p3 VALUES LESS THAN('2008-01-01'),
PARTITION p4 VALUES LESS THAN MAXVALUE)
;

/* Під час створення Foreign key в таблиці students виникає помилка: ERROR 1506: Foreign keys are not yet supported in conjunction with partitioning. 
Виходячи з того що  користувацьке партиціювання і зовнішні ключи неможливо виконати з InnoDB, 
а також за умови, що у завданні не було прямої вказівки поєднувати таблиці зв'язками у схему, зовнішні ключі не встановлювала*/

SHOW INDEXES FROM students
WHERE VISIBLE = 'yes';

SELECT * FROM students;

DESCRIBE students;

DROP TABLE IF EXISTS teachers;
CREATE TABLE IF NOT EXISTS teachers ( 
teacher_no INT(5) AUTO_INCREMENT NOT NULL, 
teacher_name VARCHAR(50) NOT NULL, 
phone_no VARCHAR(14) NOT NULL, 
PRIMARY KEY (teacher_no),
UNIQUE INDEX unique_phon(phone_no)
 ) ENGINE=INNODB
 ;

SELECT * FROM teachers;

DESCRIBE teachers;

DROP TABLE IF EXISTS courses;
CREATE TABLE IF NOT EXISTS courses ( 
course_no INT(3) AUTO_INCREMENT NOT NULL PRIMARY KEY, 
course_name VARCHAR(100) NOT NULL, 
start_date DATE NOT NULL,
end_date DATE NOT NULL
 )  ENGINE=INNODB;

SELECT * FROM courses;

DESCRIBE courses;


2.\На свое усмотрение добавить тестовые данные (7-10 строк) в наши три таблицы;

INSERT INTO students (teacher_no, course_no, student_name, email, birth_date) 
VALUES (1,2,'Ivan', 'iv_iv@com.ua','2004-09-12'),
		(1,2,'Petro', 'pt_pt@com.ua','2004-03-11'),
        (1,2,'Semen', 'sm_sm@com.ua','2004-12-10'),
        (2,1,'Viktor', 'vk_vk@com.ua','2005-12-10'),
        (2,1,'Olena', 'ol_ol@com.ua','2005-11-05'),
        (3,3,'Anna', 'an_an@com.ua','2006-02-10'),
        (3,3,'Ruslan', 'rs_rs@com.ua','2006-07-11'),
        (3,3,'Mark', 'mk_mk@com.ua','2006-05-07'),
        (4,4,'Ostap', 'os_os@com.ua','2007-02-23'),
        (4,4,'Maks', 'ms_ms@com.ua','2007-03-10'),
        (4,4,'Laima', 'lm_lm@com.ua','2007-09-08'),
        (5,6,'Lera', 'lr_lr@com.ua','2008-12-01'),
        (5,6,'Viktor', 'vk_kv@com.ua','2008-07-08'),
        (6,5,'Sveta', 'sv_sv@com.ua','2008-02-15'),
        (6,5,'Tom', 'tm_tm@com.ua','2009-01-10'),
        (6,5,'Stiv', 'st_st@com.ua','2009-08-08');

INSERT INTO teachers (teacher_name, phone_no) 
VALUES ('Ivanov', '+380678988989'),
		('Mironov', '+380678768967'),
        ('Simonov', '+380675678439'),
        ('Turov', '+380687989345'),
        ('Akimovich','+380688945673'),
        ('Saiko', '+380683456721');
        
INSERT INTO courses (course_name, start_date, end_date) 
VALUES ('IKT', '2021-09-02', '2021-12-16'),
		('Programming', '2021-09-05', '2021-12-20'),
        ('Economic theory', '2021-09-03', '2021-12-02'),
        ('Mathematics', '2021-09-04', '2022-05-22'),
        ('Cultural', '2022-01-12', '2022-05-16'),
        ('Philsophy', '2022-01-15', '2022-06-04');

3.\ Отобразить данные за любой год из таблицы students и зафиксировать в виде комментария план выполнения запроса, 
где будет видно что запрос будет выполняться по конкретной секции;

-- EXPLAIN
SELECT * FROM students 
WHERE birth_date BETWEEN '2004-01-01' AND ' 2004-12-31'
;
/* # id, select_type, table, partitions, type, possible_keys, key, key_len, ref, rows, filtered, Extra
'1', 'SIMPLE', 'students', 'p0', 'ALL', NULL, NULL, NULL, NULL, '6', '16.67', 'Using where'
*/


4.\ Отобразить данные учителя, по любому одному номеру телефона и зафиксировать план выполнения запроса, 
где будет видно, что запрос будет выполняться по индексу, а не методом ALL. 
Далее индекс из поля teachers.phone_no сделать невидимым и зафиксировать план выполнения запроса, где ожидаемый результат - метод ALL. 
В итоге индекс оставить в статусе - видимый;

-- EXPLAIN
SELECT * FROM teachers
WHERE phone_no = '+380675678439';

/* # id, select_type, table, partitions, type, possible_keys, key, key_len, ref, rows, filtered, Extra
'1', 'SIMPLE', 'teachers', NULL, 'const', 'unique_phon', 'unique_phon', '58', 'const', '1', '100.00', NULL
*/

ALTER TABLE teachers ALTER INDEX unique_phon INVISIBLE;

-- EXPLAIN
SELECT * FROM teachers
WHERE phone_no = '+380675678439';
/* # id, select_type, table, partitions, type, possible_keys, key, key_len, ref, rows, filtered, Extra
'1', 'SIMPLE', 'teachers', NULL, 'ALL', NULL, NULL, NULL, NULL, '6', '16.67', 'Using where'
*/

ALTER TABLE teachers ALTER INDEX unique_phon VISIBLE;

5.\ Специально сделаем 3 дубляжа в таблице students (добавим еще 3 одинаковые строки);

INSERT INTO students (teacher_no, course_no, student_name, email, birth_date) 
VALUES (1,2,'Leon', 'le_lev@com.ua','2006-05-17'),
		(1,2,'Leon', 'le_lev@com.ua','2006-05-17'),
        (1,2,'Leon', 'le_lev@com.ua','2006-05-17')
		;

6.Написать запрос, который выводит строки с дубляжами;

SELECT  * FROM students;

SELECT 	*
FROM 
	students
WHERE 
	email IN (SELECT email FROM students GROUP BY email HAVING COUNT(*) > 1)
	ORDER BY 1;