-- № 1
-- Отобразить информацию из таблицы сотрудников ичерез подзапрос добавитьего текущую должность.

SELECT 
    e.*,
    (SELECT 
            t.title
        FROM
            titles t
        WHERE
            t.emp_no = e.emp_no
                AND CURRENT_DATE() BETWEEN from_date AND to_date) title
FROM
    employees e;
    
-- № 2 
-- Отобразить информацию из таблицы сотрудников, которые (exists) в прошлом были с должностью 'Engineer'.
SELECT 
    e.*
FROM
    employees e
        JOIN
    titles AS t USING (emp_no)
WHERE
    EXISTS( SELECT 
            te.title
        FROM
            titles te
        WHERE
            CURRENT_DATE() BETWEEN te.from_date AND te.to_date)
        AND t.to_date < CURRENT_DATE()
        AND t.title = 'Engineer';
;

-- № 3
-- Отобразить информацию из таблицы сотрудников, у которых актуальная зарплата от 50 тысяч до 75 тысяч.
SELECT 
    e.*, s.salary
FROM
    employees e
        JOIN
    salaries AS s ON e.emp_no = s.emp_no
WHERE
    s.salary BETWEEN 50000 AND 75000
        AND CURRENT_DATE() BETWEEN s.from_date AND s.to_date;
        
-- № 4
-- Создать копию таблицы employees с помощью этогоSQL скрипта: create table employees_dub as select * from employees;
DROP TABLE IF EXISTS employees_dub;
CREATE TABLE employees_dub AS SELECT * FROM
    employees;
select * from employees_dub;

-- № 5
-- Из таблицы employees_dub удалить сотрудников которые были наняты в 1985году.
DELETE FROM employees_dub 
WHERE
    YEAR(hire_date) = 1985;

select * from employees_dub
WHERE
    YEAR(hire_date) = 1985;
    
-- № 6
-- В таблице employees_dub сотруднику под номером 10008 изменить дату приемана работу на ‘1994-09-01’.
UPDATE employees_dub 
SET 
    hire_date = '1994-09-01'
WHERE
    emp_no = 10008;

 select * from employees_dub
WHERE
    emp_no = 10008; 

-- № 7
-- В таблицу employees_dub добавить двух произвольных сотрудников.
select max(emp_no) from employees_dub;

INSERT into employees_dub (emp_no, birth_date, first_name, last_name, gender, hire_date) 
VALUES (59999,'1954-09-02','Georgiia','Facelloni','F','1987-08-20'),
		(59998,'1957-01-21','Kyoichy','Maliniak','M','1987-09-12');

 
  
 
