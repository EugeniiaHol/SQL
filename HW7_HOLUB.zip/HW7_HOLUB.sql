1\ В схеме tempdb создать таблицу dept_emp с делением по партициям по полю from_date. 
Для этого:
•Избазы данных employees таблицы dept_emp →из Info-Table inspector-DDL взять и скопировать код по созданиютой таблицы.
•Убрать из DDL кода упоминание про KEY и CONSTRAINT.
•И добавить код для секционирования по полю from_date с 1985 года до 2002. Партиции по каждому году.
HINT: CREATE TABLE... PARTITION BY RANGE (YEAR(from_date)) (PARTITION...);

CREATE DATABASE IF NOT EXISTS tempdb;

USE tempdb;

DROP TABLE IF EXISTS dept_emp;

CREATE TABLE dept_emp (
  emp_no int NOT NULL,
  dept_no char(4) NOT NULL,
  from_date date NOT NULL,
  to_date  date NOT NULL
 ) 
PARTITION BY RANGE (YEAR(from_date)) (
	PARTITION p0 VALUES LESS THAN (1986),
    PARTITION p1 VALUES LESS THAN (1987),
    PARTITION p2 VALUES LESS THAN (1988),
    PARTITION p3 VALUES LESS THAN (1989),
    PARTITION p4 VALUES LESS THAN (1990),
    PARTITION p5 VALUES LESS THAN (1991),
    PARTITION p6 VALUES LESS THAN (1992),
    PARTITION p7 VALUES LESS THAN (1993),
    PARTITION p8 VALUES LESS THAN (1994),
    PARTITION p9 VALUES LESS THAN (1995),
    PARTITION p10 VALUES LESS THAN (1996),
    PARTITION p11 VALUES LESS THAN (1997),
    PARTITION p12 VALUES LESS THAN (1998),
    PARTITION p13 VALUES LESS THAN (1999),
    PARTITION p14 VALUES LESS THAN (2000),
    PARTITION p15 VALUES LESS THAN (2001),
    PARTITION p16 VALUES LESS THAN (2002),
    PARTITION p17 VALUES LESS THAN (2003)
);

2\ Создать индекс на таблицу tempdb.dept_emp по полю dept_no;

CREATE INDEX idx_tempdb_dept_emp ON tempdb.dept_emp(dept_no);

3\ Из таблицы tempdb.dept_emp выбрать данные только за 1990 год;

SELECT * FROM tempdb.dept_emp PARTITION(p5);

4\ На основе предыдущего задания, через explain убедиться, что сканирование данных идет только по одной секции. 
Зафиксировать в виде комментария через /* вывод из explain */.
HINT: EXPLAIN SELECT ... FROM ... WHERE ...;

EXPLAIN SELECT * FROM tempdb.dept_emp PARTITION(p5); /* 1, SIMPLE, dept_emp, p5, ALL, , , , , 1, 100.00, */ -- таблиця наразі пуста, тому при спробі встановити умову по полю dept_no видає помилку...

EXPLAIN SELECT * FROM tempdb.dept_emp WHERE dept_no = 'd001'; -- вже завантажені дані до таблиці і виводятьс відповідно до індексу
/* '1', 'SIMPLE', 'dept_emp', 'p0,p1,p2,p3,p4,p5,p6,p7,p8,p9,p10,p11,p12,p13,p14,p15,p16,p17', 'ref', 'idx_tempdb_dept_emp', 'idx_tempdb_dept_emp', '16', 'const', '176', '100.00', 'Using index condition' */ 



5\ Загрузить свой любой CSV файл в схему tempdb.HINT: LOAD DATA INFILE ... INTO TABLE ...;
-- імпортувала дані з файлу dept_emp.csv, який є результатом експорту таблиці employees.dept_emp, двома способами через консоль і через інструменти Workbench.

LOAD DATA INFILE 'C:/\Program Files/\MySQL/\MySQL Server 8.0/\Uploads/\dept_emp.csv' INTO TABLE tempdb.dept_emp
  FIELDS TERMINATED BY ',' ENCLOSED BY '"' LINES TERMINATED BY '\n' IGNORE 1 LINES
  (emp_no, dept_no, from_date, to_date);
  
  