-- For the current maximum annual wage in the company SHOW the full name of an employee, department, current position, 
-- for how long the current position is held, and total years of service in the company.
-- USE common table expression this time

-- 1.Для поточної максимальної річної заробітної плати в компанії ПОКАЖІТЬ ПІБ співробітника, відділ, поточну посаду, 
-- тривалість поточної посади та загальний стаж роботи в компанії. Цього разу ВИКОРИСТОВУЙТЕ звичайний табличний вираз.

DROP TABLE IF EXISTS max_year_salary;
CREATE TABLE max_year_salary AS 
SELECT 
    e.first_name,
    e.last_name,
    t.title,
    de.dept_no,
    TIMESTAMPDIFF(YEAR,
        t.from_date,
        CURRENT_DATE()) AS duration,
    TIMESTAMPDIFF(YEAR,
        e.hire_date,
        CURRENT_DATE()) AS services_length
FROM
    employees AS e
        JOIN
    salaries AS s ON e.emp_no = s.emp_no
        JOIN
    titles AS t ON e.emp_no = t.emp_no
    JOIN
    dept_emp AS de ON e.emp_no = de.emp_no
WHERE
    CURRENT_DATE() BETWEEN t.from_date AND t.to_date
        AND s.salary = (SELECT 
            MAX(s.salary)
        FROM
            salaries AS s where CURRENT_DATE() BETWEEN s.from_date AND s.to_date)
;
    
 -- 2. From MySQL documentation check how ABS() function works. 
 -- https://dev.mysql.com/doc/refman/8.0/en/mathematical-functions.html#function_abs
SELECT ABS(2) abs;
SELECT ABS(-32) abs;


-- 3. Show all information about the employee, salary year, and the difference between salary and 
-- average salary in the company overall. For the employee, whose salary was assigned latest from salaries 
-- that are closest to mean salary overall (doesn’t matter higher or lower). 
-- Here you need to find the average salary overall and then find the smallest difference of someone’s salary 
-- with an average salary

-- Показати всю інформацію про працівника, рік заробітної плати та різницю між зарплатою та середньою заробітною 
-- платою по компанії в цілому. Для працівника, чия заробітна плата була призначена останньою з окладів, 
-- найближчих до середньої загальної заробітної плати (не має значення вище чи нижче). 
-- Тут потрібно знайти середню зарплату в цілому, а потім знайти найменшу різницю чиєїсь зарплати з середньою зарплатою

DROP TABLE IF EXISTS tab1; -- Створила додаткову таблицю для полегшання операцій зі стовпцями (колонками)
CREATE TABLE tab1 AS     
SELECT 
    e.emp_no,
    e.first_name,
    e.last_name, 
    YEAR(s.from_date) year_s, 
    s.salary,
    (SELECT 
            AVG(salary)
        FROM
            salaries) avg_s,
    ABS(s.salary - (SELECT 
                    AVG(salary)
                FROM
                    salaries)) disp
FROM
    employees e
        JOIN
    salaries s ON e.emp_no = s.emp_no
 order by disp
;

-- безпосередньо розв'язання з використанням проміжної таблиці:
SELECT * FROM tab1;
SELECT 
    t1.emp_no, t1.first_name, t1.last_name, t1.year_s, t1.disp
FROM
    tab1 t1
WHERE
    salary - avg_s = (SELECT 
            MIN(disp)
        FROM
            tab1)
        AND t1.year_s = (SELECT 
            MAX(year_s)
        FROM
            tab1)
;
            

-- 4.Select the details, title, and salary of the employee with the highest salary who is not employed in the company anymore.
-- 4. Виберіть реквізити, посаду та оклад працівника з найвищою зарплатою, який більше не працює в компанії.
select * from salaries;
Спосіб 1;
CREATE VIEW release_tab AS
    SELECT 
        emp_no, MAX(salary) max_s, MAX(to_date) max_d
    FROM
        salaries
    GROUP BY emp_no
    HAVING max_d != '9999-01-01';

SELECT * FROM release_tab;

SELECT 
    e.first_name,
    e.last_name,
    t.title,
    MAX(r.max_s) max_sal
  FROM
    employees e
        JOIN
    release_tab r ON e.emp_no = r.emp_no
        LEFT JOIN
    titles t ON (e.emp_no = t.emp_no
        AND r.max_d = t.to_date)
        ;

Спосіб 2;
WITH release_tab (emp_no,
    max_s,
    max_d)
AS ( SELECT 
        emp_no, MAX(salary), MAX(to_date)
    FROM
        salaries
    GROUP BY emp_no
    HAVING max_d != '9999-01-01');
SELECT * FROM release_tab;

SELECT 
    e.first_name,
    e.last_name,
    t.title,
    MAX(r.max_s) max_sal
  FROM
    employees e
        JOIN
    release_tab r ON e.emp_no = r.emp_no
        LEFT JOIN
    titles t ON (e.emp_no = t.emp_no
        AND r.max_d = t.to_date)
        ;

-- 5. Show Full Name, salary, and year of the salary for top 5 employees that have the highest one-time raise in salary 
-- (in absolute numbers). Also, attach the top 5 employees that have the highest one-time raise in salary (in percent).  
-- One-time rise here means the biggest difference between the two consecutive years
-- Показати ПІБ, зарплату та рік заробітної плати для 5 найкращих співробітників, 
-- які мають найвище одноразове підвищення заробітної плати (в абсолютних числах). 
-- Крім того, додайте 5 найкращих співробітників, які мають найвище одноразове підвищення заробітної плати (у відсотках). 
-- Одноразове підвищення тут означає найбільшу різницю між двома роками поспіль.

Створення 1-ї таблиці;
DROP VIEW IF EXISTS TAB_1;
CREATE VIEW TAB_1 AS
SELECT 
    s.emp_no,
    e.first_name,
    e.last_name,
    round(max(s.salary - sa.salary),0) maximum 
FROM
    salaries s
    INNER JOIN salaries sa on (s.emp_no = sa.emp_no
                AND YEAR(s.from_date) = YEAR(sa.from_date)+1)
    INNER JOIN employees e on s.emp_no = e.emp_no
GROUP BY s.emp_no
ORDER BY maximum DESC
LIMIT 5
;
Створення 2-ї таблиці;
DROP VIEW IF EXISTS TAB_2;
CREATE VIEW TAB_2 AS
SELECT 
    s.emp_no,
    e.first_name,
    e.last_name,
   round(max(sa.salary/s.salary)*100,0) maximum
FROM
    salaries s
    INNER JOIN salaries sa on (s.emp_no = sa.emp_no
                AND YEAR(s.from_date) = YEAR(sa.from_date)+1)
    INNER JOIN employees e on s.emp_no = e.emp_no
GROUP BY s.emp_no
ORDER BY maximum DESC
LIMIT 5
;
Поєднання 2-х таблиць;
SELECT *, 'increase' as tab_name  FROM TAB_1
UNION ALL
SELECT *, 'rate' as tab_name FROM TAB_2;

-- 6. Generate a sequence of square numbers till 9 (1^2, 2^2... 9^2)
-- 6. Створіть послідовність квадратних чисел до 9 (1^2, 2^2... 9^2)
WITH RECURSIVE 
power (sr_no, n) AS
(
SELECT 1, 1 
union all
SELECT sr_no+1, pow(sr_no+1,2) from power where sr_no < 9
) 
SELECT * FROM power; 