-- №1
-- Показать для каждого сотрудника его текущую зарплату и текущую зарплату текущего руководителя.

SELECT 
    de.emp_no,
    s.salary,
    dm.emp_no AS manager,
    sm.salary AS manag_sal
FROM
    dept_emp AS de
        JOIN
    salaries AS s ON de.emp_no = s.emp_no
        LEFT JOIN
    dept_manager AS dm ON de.dept_no = dm.dept_no
        LEFT JOIN
    salaries AS sm ON dm.emp_no = sm.emp_no
WHERE
    CURRENT_DATE() BETWEEN dm.from_date AND dm.to_date
        AND CURRENT_DATE() BETWEEN sm.from_date AND sm.to_date
        AND CURRENT_DATE() BETWEEN s.from_date AND s.to_date
GROUP BY de.emp_no
ORDER BY dm.emp_no , emp_no;

-- №2
-- Показать всех сотрудников, которые в настоящее время зарабатывают больше,чем их руководители.

SELECT 
    de.emp_no,
    s.salary,
    dm.emp_no AS manager,
    sm.salary AS manag_sal
FROM
    dept_emp AS de
        JOIN
    salaries AS s ON de.emp_no = s.emp_no
        LEFT JOIN
    dept_manager AS dm ON de.dept_no = dm.dept_no
        LEFT JOIN
    salaries AS sm ON dm.emp_no = sm.emp_no
WHERE
       CURRENT_DATE() BETWEEN de.from_date AND de.to_date AND
       CURRENT_DATE() BETWEEN dm.from_date AND dm.to_date
        AND CURRENT_DATE() BETWEEN sm.from_date AND sm.to_date
        AND CURRENT_DATE() BETWEEN s.from_date AND s.to_date
        AND s.salary > sm.salary
ORDER BY dm.emp_no , de.emp_no
;

-- №3
-- Из таблицы dept_manager первым запросом выбрать данные по актуальным менеджерам департаментов 
-- и сделать свой столбец “checks” со значением ‘actual’.
-- Вторым запросом из этой же таблицы dept_manager выбрать НЕ актуальных менеджеров департаментов 
-- и сделать свой столбец “checks” со значением ‘old’.Объединить результат двух запросов через union.

SELECT 
    emp_no AS checks, 'actual'
FROM
    dept_manager
WHERE
    CURRENT_DATE() BETWEEN from_date AND to_date 
UNION SELECT 
    emp_no AS checks, 'old'
FROM
    dept_manager
WHERE
    CURRENT_DATE() NOT BETWEEN from_date AND to_date;

-- №4
-- К результату всех строк таблицы departments, добавитьеще две строки со значениями 
-- “d010”, “d011” для dept_no и “Data Base”,“Help Desk” для dept_name

-- select * from departments;
insert departments (dept_no, dept_name)
values
('d010','Data Base'),
('d011','Help Desk');

-- №5
-- Найти emp_no актуального менеджера из департамента‘d003’, далее через подзапрос из таблицы сотрудников вывести по нему информацию.

# з підзапитом, але по номеру менеджера
SELECT 
    e.emp_no,
    e.first_name,
    e.last_name,
    e.birth_date,
    e.gender,
    e.hire_date
FROM
    employees AS e
WHERE
    (SELECT 
            dm.emp_no
        FROM
            dept_manager AS dm
        WHERE
            dm.dept_no = 'd003'
                AND CURRENT_DATE() BETWEEN dm.from_date AND dm.to_date) = e.emp_no
; 

# без підзапиту, але результат такий, як в першому варіанті
SELECT  
    dm.emp_no,
    e.first_name,
    e.last_name,
    e.birth_date,
    e.gender,
    e.hire_date
FROM
    dept_manager AS dm,
    employees AS e
WHERE
    dm.emp_no = e.emp_no
        AND dm.dept_no = 'd003'
        AND CURRENT_DATE() BETWEEN dm.from_date AND dm.to_date; 

-- №6 
-- Найти максимальную дату приема на работу, далее через подзапрос из таблицы сотрудников вывести по этой дате информацию по сотрудникам.
SELECT 
    e.*
FROM
    employees e
WHERE
    (SELECT 
            MAX(hire_date)
        FROM
            employees) = e.hire_date
;