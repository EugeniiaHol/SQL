DROP DATABASE IF EXISTS tempdb;
CREATE DATABASE IF NOT EXISTS tempdb;
USE tempdb;

1 / Создать таблицу client с полями:
• clnt_no ( AUTO_INCREMENT первичный ключ)
• cnlt_name (нельзя null значения)
• clnt_tel (нельзя null значения)
• clnt_region_no;

CREATE TABLE IF NOT EXISTS clients(
    clnt_no INT AUTO_INCREMENT PRIMARY KEY,
    cnlt_name VARCHAR(40) NOT NULL,
    clnt_tel VARCHAR(10) NOT NULL,
    clnt_region_no INT
) ENGINE=INNODB
;

DESCRIBE clients;

2 / Создать таблицу sales с полями:
• clnt_no (внешний ключ на таблицу client поле clnt_no; режим RESTRICT для
update и delete)
• product_no (нельзя null значения)
• date_act (по умолчанию текущая дата);

 CREATE TABLE IF NOT EXISTS sales (
    clnt_no INT,
    product_no INT NOT NULL,
    date_act TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
   
   FOREIGN KEY (clnt_no)
   REFERENCES clients (clnt_no)
   ON UPDATE RESTRICT ON DELETE RESTRICT
    ) ENGINE=INNODB;

DESCRIBE sales;

3 / Добавить 5 клиентов (тестовые данные на свое усмотрение) в таблицу clients;

INSERT INTO clients(cnlt_name, clnt_tel, clnt_region_no) 
VALUES
('Tom','1234567',1),
('Nick','2345678',2),
('Pit','3456789',2),
('Rick','4567890',3),
('Sem','1345789',3);

SELECT * from clients;
 
4 / Добавить по 2 продажи для каждого сотрудника (тестовые данные на свое усмотрение ) в таблицу sales;

INSERT INTO sales (clnt_no, product_no) 
VALUES
(1,12),
(1,11),
(2,34),
(2,24),
(3,20),
(3,12),
(4,11),
(4,34),
(5,24),
(5,20);

SELECT * from sales;

5 / Из таблицы client, попробовать удалить клиента с clnt_no=1 и увидеть ожидаемую
ошибку. Ошибку зафиксировать в виде комментария через /* ошибка */;
DELETE FROM clients 
WHERE
     clnt_no=1;
     /* Error Code: 1451. Cannot delete or update a parent row: 
     a foreign key constraint fails (`tempdb`.`sales`, CONSTRAINT `sales_ibfk_1` FOREIGN KEY (`clnt_no`) REFERENCES `clients` (`clnt_no`) 
     ON DELETE RESTRICT ON UPDATE RESTRICT)	0.234 sec */

6 / Удалить из sales клиента по clnt_no=1, после чего повторить удаление из client по
clnt_no=1 (ошибки в таком порядке не должно быть);
DELETE FROM sales 
WHERE
     clnt_no=1;
     /*2 row(s) affected	0.188 sec */
DELETE FROM clients 
WHERE
     clnt_no=1;
    /*1 row(s) affected	0.110 sec */
 
7 / Из таблицы client удалить столбец clnt_region_no;
 ALTER TABLE clients
 DROP COLUMN clnt_region_no;

8 / В таблице client переименовать поле clnt_tel в clnt_phone;
ALTER TABLE clients RENAME COLUMN clnt_tel TO clnt_phone;

SELECT * from clients;
 

9 / Удалить данные в таблице departments_dup с помощью DDL оператора truncate; 

USE `employees`;

TRUNCATE TABLE departments_dup;

SELECT * from departments_dup;